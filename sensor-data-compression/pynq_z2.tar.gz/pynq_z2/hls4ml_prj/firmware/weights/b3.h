//Numpy array shape [8]
//Min -0.250000000000
//Max 0.187500000000
//Number of zeros 1

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
bias3_t b3[8];
#else
bias3_t b3[8] = {-0.1250, -0.2500, -0.0625, 0.0000, -0.1875, -0.1875, -0.2500, 0.1875};
#endif

#endif
