//Numpy array shape [16]
//Min 0.375000000000
//Max 1.937500000000
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[16];
#else
bias7_t b7[16] = {0.7500, 0.9375, 0.5625, 0.7500, 1.9375, 1.0000, 1.3125, 1.1875, 0.7500, 0.3750, 1.3750, 0.8125, 1.8125, 0.6250, 1.5000, 0.6250};
#endif

#endif
